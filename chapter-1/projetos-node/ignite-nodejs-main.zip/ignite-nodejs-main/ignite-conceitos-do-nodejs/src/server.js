const app = require('./index');

app.listen(3333);